using ApplicationCore.Models.QuizAggregate;
using FluentValidation;

namespace WebApi.Validators;

public class QuizItemValidator : AbstractValidator<QuizItem>
{
    public QuizItemValidator()
    {
        RuleFor(q => q.Question)
            .MaximumLength(200).WithMessage("Pytanie nie może być dłuższe niż 200 znaków")
            .MinimumLength(5);
        RuleForEach(q => q.IncorrectAnswers)
            .MinimumLength(1)
            .MaximumLength(200);
        RuleFor(q => new { q.IncorrectAnswers, q.CorrectAnswer })
            .Must(o => !o.IncorrectAnswers.Contains(o.CorrectAnswer))
            .WithMessage("Poprawna odpowiedź nie może występować w liscie niepoprawnych");
        RuleFor(q => q.IncorrectAnswers)
            .Must(o => o.Count > 0)
            .WithMessage("Lista niepoprawnych odpowiedzi nie może być pusta");
    }
}