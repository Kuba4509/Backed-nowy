namespace WebApi.DTO;

public class QuizItemUserAnswerDTO
{
    public string Answer { get; set; }
}